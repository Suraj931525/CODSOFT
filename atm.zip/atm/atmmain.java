package atm;

public class atmmain {
	
	    public static void main(String[] args) {
	        BankAccount myAccount = new BankAccount(5000.0);
	        ATM atm = new ATM(myAccount);
	        atm.showMenu();
	    }
	}


